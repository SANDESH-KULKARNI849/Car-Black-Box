/*
 *Name:A20-Implement a right scrolling message marquee.
 *date=25-02-2025
 */

#include <xc.h>
#include "clcd.h"
#include "matrix_keypad.h"
#include "uart.h"
#include "ds1307.h"
#include "EEPROM_ext.h"

unsigned int event_index=0;
unsigned char time[9]="00:00:00";//to display time
unsigned char key,hr,min,sec;

enum home flag=0;

static void get_time(void)//to dispaly time
{
	hr = read_ds1307(HOUR_ADDR);
	min = read_ds1307(MIN_ADDR);
	sec = read_ds1307(SEC_ADDR);

	if (hr & 0x40)//0x00 means 24 hr format and 0x04 means 12 hr format
	{
		time[0] = '0' + ((hr >> 4) & 0x01);
		time[1] = '0' + (hr & 0x0F);
	}
	else
	{
		time[0] = '0' + ((hr >> 4) & 0x03);
		time[1] = '0' + (hr & 0x0F);
	}
	time[2] = ':';
	time[3] = '0' + ((min >> 4) & 0x0F);
	time[4] = '0' + (min & 0x0F);
	time[5] = ':';
	time[6] = '0' + ((sec >> 4) & 0x0F);
	time[7] = '0' + (sec & 0x0F);
	time[8] = '\0';
}

void init_adc()
{
    CHS2=1;//SELECTED THE AN4(POTENTIOMETER)
    CHS3=CHS1=CHS0=0;
    
    ADON=1;//ADC enabled
    GO=0;//NO CONVERSION STARTED
    
    VCFG1=VCFG0=00;//NO REFERENCE VOLTAGE
            
    PCFG3=1;//make AN4 as analog channel
    PCFG2=0;
    PCFG1=1;
    PCFG0=0;
    
    ADFM=1;//RIGHT JUSTIFIED
    
    ADCS2=0;//CLOCK SPEED OF 0.0625MHZ
    ADCS1=1;
    ADCS0=0;
    
    ACQT2=1;//8TAD(12.86 micro sec of ACQ time)
    ACQT1=0;
    ACQT0=0;
}

static void init_config(void)
{
    init_clcd();
    init_adc();
    init_matrix_keypad();
    init_uart();
    init_i2c();
	init_ds1307();
}

void main(void)
{   
    init_config();
    
    while (1)
    {
        get_time();
        key = read_switches(STATE_CHANGE);
        if(flag == dashboard)
        {
            //call dash_board function
            dash_board();   
        }
        else if(flag == menu_mode)
        {
            //to display menu
            menu_opt();
        }
        else if(flag == view)
        {
            view_log();
        }
        else if(flag == download)
        {
            download_log();
        }
        else if(flag == clear)
        {
            clear_log();
        }
        else if(flag == set_time)
        {
            time_modify();
        }
    }
}