#include <xc.h>
#include "clcd.h"
#include "matrix_keypad.h"
#include "ds1307.h"

extern unsigned char time[9];
extern char key;
unsigned char hr1=0,min1=0,sec1=0;
unsigned int flag3=0,delay=0,edit_flag=0,blink_flag=0;
extern enum home flag;
int field=0;

void time_modify(void) 
{
    static unsigned char last_key=0;
    clcd_print("    HH:MM:SS    ",LINE1(0));
    
    if(flag3==0)
    {
        hr1=((time[0]-'0')*10+(time[1]-'0'));//hour
        min1=((time[3]-'0')*10+(time[4]-'0'));//min
        sec1=((time[6]-'0')*10+(time[7]-'0'));//sec
        flag3=1;
    }
    clcd_print("    ",LINE2(0));

    if(delay++ == 250)
    {
        delay=0;
        blink_flag=!blink_flag;
    }
    if(edit_flag && blink_flag && field == 0)
    {
        clcd_print("  ",LINE2(4));  
    }
    else
    {
        clcd_putch(hr1/10+'0',LINE2(4));
        clcd_putch(hr1%10+'0',LINE2(5));
    }
    clcd_print(":",LINE2(6));
    if(edit_flag && blink_flag && field == 1)
    {
        clcd_print("  ",LINE2(7));  
    }
    else
    {
        clcd_putch(min1/10+'0',LINE2(7));
        clcd_putch(min1%10+'0',LINE2(8));
    }
    clcd_print(":",LINE2(9));
    if(edit_flag && blink_flag && field == 2)
    {
        clcd_print("  ",LINE2(10));  
    }
    else
    {
        clcd_putch(sec1/10+'0',LINE2(10));
        clcd_putch(sec1%10+'0',LINE2(11));
    }
    if(key != last_key)
    {
        if(key == MK_SW3)
        {
            edit_flag=1;
            field++;
            if(field > 2)field=0;  
        }
        if(edit_flag)//hr field
        {
            if(key == MK_SW2)
            {
                if(field == 0)
                {
                    hr1++;
                    if(hr1 > 23)hr1=0;
                }
                else if(field == 1)
                {
                    min1++;
                    if(min1 > 59)min1=0;
                }
                else if(field == 2)
                {
                    sec1++;
                    if(sec1 > 59)sec1=0;
                }
            }
        }
    }
    last_key=key;
    
    if(key == MK_SW4)
    {
        hr1=((hr1/10) <<4 ) | (hr1%10);
        write_ds1307(HOUR_ADDR,hr1);//to write the new hour in RTC.
        
        min1=((min1/10) <<4 ) | (min1%10);
        write_ds1307(MIN_ADDR,min1);//to write the new hour in RTC.
        
        sec1=((sec1/10) <<4 ) | (sec1%10);
        write_ds1307(SEC_ADDR,sec1);//to write the new hour in RTC.
        
        flag=menu_mode;
    }
    if(key == MK_SW5)//exiting without saving in RTC.
        flag=menu_mode;
    
}
