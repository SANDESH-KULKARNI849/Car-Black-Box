
#include <xc.h>
#include "clcd.h"
#include "matrix_keypad.h"

extern int lap;
extern enum home flag;

void clear_log(void) 
{
    lap=0;
    int i=0;
    clcd_print("Clear Log:-   ",LINE1(0));
    while(i < 4000)
    {
        clcd_print("  No Data Found ",LINE2(0));//when NO event is stored.
        i++;
    }
    flag=menu_mode;
}
