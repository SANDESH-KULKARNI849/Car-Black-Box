
#include <xc.h>
#include "clcd.h"
#include "matrix_keypad.h"


char menu_index=0,star_flag=0;//starflag for cursor and menuindex for displaying the menu in CLCD.
extern unsigned char key;
extern enum home flag;

void menu_opt(void) 
{
    if(key == MK_SW5)//if switch 5 is pressed it should go to dashboard
    {
        flag=dashboard;
    }
    
    if(key == MK_SW4)
    {
        //check the star_flag and call that particular fun.
        if(view == menu_index+star_flag+2)
        {
            flag=view;
        }
        else if(download == menu_index+star_flag+2)
        {
            flag=download;
        }
        else if(clear == menu_index+star_flag+2)
        {
            flag=clear;
        }
        else if(set_time == menu_index+star_flag+2)
        {
            flag=set_time;
        }
        
        if(key == MK_SW5)
        {
            flag=menu_mode;
        }
    }
    clcd_print(menu[menu_index],LINE1(1));
    clcd_print(menu[menu_index + 1],LINE2(1));
    if(!star_flag)
    {
        clcd_putch('*',LINE1(0));
        clcd_putch(' ',LINE2(0));
    }
    else
    {
        clcd_putch(' ',LINE1(0));
        clcd_putch('*',LINE2(0));
    }
    
    if(key == MK_SW3)//to scroll down in the menu
    {
        if(star_flag == 0)star_flag=1;
        else if(menu_index < 2)
        {
            menu_index++;
        }
    }
    else if(key == MK_SW2)//to scroll up in the menu
    {
        if(star_flag == 1)star_flag=0;
        else if(menu_index > 0)
        {
            menu_index--;
        }
    }
    return;
}
