#include <xc.h>
#include "clcd.h"
#include "matrix_keypad.h"
#include "EEPROM_ext.h"

extern char event[][3],key;
extern int lap;
extern enum home flag;

void view_log(void) 
{
    clcd_print("View Log:-",LINE1(0));
    static unsigned char index=0;
    unsigned char arr[5];
    int i=0;
   
    if(lap==0)
    {
        while(i < 4000)
        {
            clcd_print("  No Data Found ",LINE2(0));//when NO event is stored.
            i++;
        }
        flag=menu_mode;
    }
    if(key==MK_SW2) //scroll up
    {
        if(index > 0)index--;
    }
    else if(key==MK_SW3) //scroll down
    {
        if(index < lap-1)index++;
    }
    
    if(key == MK_SW5)//if switch 5 is pressed it should go to menu
    {
        flag=menu_mode;
    }
    
    if(index<=lap)
    {
        for(char i=0;i<5;i++)
        {
            arr[i]=read_external_EEPROM(i+index*5);
        }
        clcd_putch((index)+48,LINE2(0));//for display serial_number
        
        clcd_putch(' ',LINE2(1));
        clcd_putch(((arr[0]/10)+'0'),LINE2(2));
        clcd_putch(((arr[0]%10)+'0'),LINE2(3));
        clcd_putch(':',LINE2(4));
        clcd_putch(((arr[1]/10)+'0'),LINE2(5));
        clcd_putch(((arr[1]%10)+'0'),LINE2(6));
        clcd_putch(':',LINE2(7));
        clcd_putch(((arr[2]/10)+'0'),LINE2(8));
        clcd_putch(((arr[2]%10)+'0'),LINE2(9));
        clcd_putch(' ',LINE2(10));

        //events
        clcd_print(event[arr[3]],LINE2(11));

        //speed
        clcd_putch(' ',LINE2(13));
        clcd_putch(((arr[4]/10)+'0'),LINE2(14));
        clcd_putch(((arr[4]%10)+'0'),LINE2(15));
    }
    
    return;
}
