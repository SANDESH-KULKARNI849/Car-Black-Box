#ifndef Ds1307
#define Ds1307

#define SLAVE_READ		0xA1
#define SLAVE_WRITE		0xA0


void write_external_EEPROM(unsigned char address, unsigned char data);
unsigned char read_external_EEPROM(unsigned char address);

#endif