#include <xc.h>
#include "clcd.h"
#include "matrix_keypad.h"
#include "uart.h"
#include "EEPROM_ext.h"

extern char event[][3];
extern int lap;
extern enum home flag;
void download_log(void) 
{
    unsigned char arr[5];
    unsigned int i=0;
    clcd_print(" Download Log:- ",LINE1(0));

    if(lap==0)
    {
        while(i<4000)
        {
            clcd_print("  No Data Found ",LINE2(0));
            i++;
        }
        flag=menu_mode;
    }
    puts("Downloading....\n\r#   TIME   EV  SP\n\r");
    for(char serial=0;serial<10;serial++)
    {
        if(serial<=lap)
        {
            for(char i=0;i<5;i++)
            {
                arr[i]=read_external_EEPROM(i+serial*5);
            }
            putch(serial+48);
            //time
            putch(' ');
            putch(((arr[0]/10)+48));
            putch(((arr[0]%10)+48));
            putch(':');
            putch(((arr[1]/10)+48));
            putch(((arr[1]%10)+48));
            putch(':');
            putch(((arr[2]/10)+48));
            putch(((arr[2]%10)+48));
            putch(' ');

            //events
            //putch(' ');
            puts(event[arr[3]]);

            //speed
            putch(' ');
            putch(((arr[4]/10)+48));
            putch(((arr[4]%10)+48));
            puts("\n\r");
        }
    }

    while(i<4000)
    {
        clcd_print("  SUCCESSFULLY  ",LINE2(0));
        i++;
    }
    flag=menu_mode;
    return;
}
