#include <xc.h>
#include "clcd.h"
#include "matrix_keypad.h"
#include "EEPROM_ext.h"

extern unsigned char key;
extern unsigned int event_index=0;
extern unsigned char time[9];
unsigned short temp=0;
extern enum home flag;
char arr[10];
int i=0,crash=0,lap=0;

void store_data()
{

    arr[0]=((time[0]-'0')*10+(time[1]-'0'));//hour
    arr[1]=((time[3]-'0')*10+(time[4]-'0'));//min
    arr[2]=((time[6]-'0')*10+(time[7]-'0'));//sec
    
    arr[3]=event_index;//state of the car
    arr[4]=temp;//speed of car
    if(lap == 10)
    {
        lap=9;
        for(int k=5;k<50;k++)
        {
            char temp2=read_external_EEPROM(k);
            write_external_EEPROM(k-5,temp2);
        }
    }
    
    for(i=0;i<5;i++)
    {
        write_external_EEPROM(i + (lap*5),arr[i]);
    }
    lap++;
}

unsigned short read_adc()
{
    GO=1;//start conversion
    while(GO);//wait untill conversion complete
    return (ADRESH<<8) | ADRESL;
}

void dash_board(void) 
{
    if(key == MK_SW4)
    {
        flag=menu_mode;
    }
    unsigned short adc_val;
   
    clcd_print("TIME      EV  SP",LINE1(0));
    clcd_print("  ",LINE2(8));
    clcd_print("  ",LINE2(12));
    clcd_print(time,LINE2(0));
    
    adc_val=read_adc();
    temp=adc_val/10.33;
    clcd_putch(temp/10+'0',LINE2(14));// 1st digit
    clcd_putch(temp%10+'0',LINE2(15));// 2nd digit
    if(key == MK_SW2)
    {      
        if(event_index <= 6)
        {
            event_index++;
        }
    }
    else if(key == MK_SW3)
    {
        if(event_index > 1)
            event_index--;
        if(event_index == 0)
            event_index++;
    }
    else if(key == MK_SW1)
    {
        event_index=8;
        crash=1;
    }
    if(crash == 1)
    {
        if(key == MK_SW2 || key == MK_SW3)
        {
            event_index=2;
            crash=0;
        }
    } 
    if(key == MK_SW1 || key == MK_SW2 || key == MK_SW3)
    {
        store_data();
    }
    clcd_print(event[event_index],LINE2(10));//to print the events.
}
